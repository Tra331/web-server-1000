
document.addEventListener('DOMContentLoaded', () => {
    console.log('Welcome to IT Management!');
});
